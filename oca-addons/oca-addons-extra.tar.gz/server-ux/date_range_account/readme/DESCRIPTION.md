This is a small glue module between **date_range** and **account**. It
allows the *Accounting Manager* to access the *Date Range* menu entry
under *Invoicing \> Configuration \> Date Range*.

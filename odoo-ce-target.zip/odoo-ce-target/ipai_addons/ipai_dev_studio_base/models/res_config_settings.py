# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Development Studio Base
# Configuration Settings
# =============================================================================

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    """Extend settings with InsightPulse dev options."""
    
    _inherit = "res.config.settings"

    ipai_dev_mode = fields.Boolean(
        string="InsightPulse Dev Mode",
        config_parameter="ipai.dev_mode",
        help="Enable development features and debugging tools.",
    )
    
    ipai_hide_enterprise_upsells = fields.Boolean(
        string="Hide Enterprise Upsells",
        config_parameter="ipai.hide_enterprise_upsells",
        default=True,
        help="Hide Enterprise and IAP upsell banners throughout the UI.",
    )
    
    ipai_workspace_enabled = fields.Boolean(
        string="Workspaces Enabled",
        config_parameter="ipai.workspace_enabled",
        default=True,
        help="Enable Notion-style workspaces for organizing work.",
    )

Technical module to share easily deal with XML attachments in PDF files.

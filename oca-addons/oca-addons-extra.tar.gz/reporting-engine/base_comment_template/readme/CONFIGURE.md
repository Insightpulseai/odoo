Go to *Settings \> Technical \> Reporting \> Comment Templates* and
start designing you comment templates.

This module is the base module for following modules:

- sale_comment_template
- purchase_comment_template
- invoice_comment_template
- stock_picking_comment_template

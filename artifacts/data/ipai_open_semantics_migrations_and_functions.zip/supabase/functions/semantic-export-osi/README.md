# semantic-export-osi

Exports a semantic model + dims + metrics for an asset.

## Env
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY

## Request
GET /functions/v1/semantic-export-osi?asset_fqdn=...&model_name=default&format=both
Authorization: Bearer <token>

format:
- json (default)
- yaml
- both

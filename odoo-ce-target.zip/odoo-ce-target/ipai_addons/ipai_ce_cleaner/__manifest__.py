# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - CE Cleaner
# =============================================================================
# Ensures clean CE-only architecture by removing Enterprise/IAP references
# =============================================================================
{
    "name": "InsightPulse CE Cleaner",
    "version": "18.0.1.0.0",
    "category": "Technical",
    "summary": "Remove Enterprise and IAP dependencies for clean CE architecture",
    "description": """
InsightPulse CE Cleaner
=======================

Ensures the Odoo installation remains pure Community Edition by:
- Disabling IAP services
- Hiding Enterprise upsell messages
- Removing Enterprise module suggestions
- Blocking Enterprise module installation attempts

This module is part of the "18 oca" target image strategy ensuring
no Enterprise contamination in the deployment.

License: LGPL-3
    """,
    "author": "InsightPulseAI",
    "website": "https://erp.insightpulseai.net",
    "license": "LGPL-3",
    "depends": [
        "base",
        "web",
    ],
    "data": [
        "data/iap_disable.xml",
    ],
    "demo": [],
    "installable": True,
    "application": False,
    "auto_install": True,  # Auto-install to ensure CE cleanliness
}

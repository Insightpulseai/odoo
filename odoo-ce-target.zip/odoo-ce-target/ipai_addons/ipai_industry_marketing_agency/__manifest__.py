# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Marketing Agency Industry Pack
# =============================================================================
# Specialized workspaces for marketing agency brand and campaign management
# =============================================================================
{
    "name": "InsightPulse Marketing Agency",
    "version": "18.0.1.0.0",
    "category": "Marketing",
    "summary": "Marketing agency workspace bundle with brand and campaign management",
    "description": """
InsightPulse Marketing Agency Industry Pack
==========================================

Specialized workspaces and workflows for marketing agencies managing brands and campaigns.

Features
--------
* Per-brand workspaces (marketing_brand type)
* Per-campaign workspaces (marketing_campaign type)
* Brand asset and guideline management
* Campaign budget tracking
* Integration with Projects, Events, and CRM

Brand Workspace Extensions
--------------------------
* brand_code: Unique brand identifier
* main_project_id: Primary brand project
* brand_guidelines: Brand guideline documentation

Campaign Workspace Extensions
-----------------------------
* campaign_project_id: Link to campaign project
* budget_amount: Campaign budget tracking
* start_date / end_date: Campaign timeline

Usage
-----
Install this module to enable "Brand Workspaces" and "Campaign Workspaces" menus
with marketing-specific fields and workflows.

License: LGPL-3
    """,
    "author": "InsightPulseAI",
    "website": "https://erp.insightpulseai.net",
    "license": "LGPL-3",
    "depends": [
        "ipai_workspace_core",
        "crm",
        "sale_management",
        "project",
        "calendar",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/workspace_marketing_views.xml",
        "views/workspace_marketing_menus.xml",
    ],
    "demo": [],
    "installable": True,
    "application": False,
    "auto_install": False,
}

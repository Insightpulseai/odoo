# InsightPulse ERP Target Image

**Odoo 18 CE/OCA + Notion-style AI Business Workspaces**

[![Build Status](https://github.com/jgtolentino/odoo-ce/workflows/Build%20%26%20Deploy%20Target%20Image/badge.svg)](https://github.com/jgtolentino/odoo-ce/actions)
[![License: LGPL-3](https://img.shields.io/badge/License-LGPL%20v3-blue.svg)](https://www.gnu.org/licenses/lgpl-3.0)

## Overview

This is the canonical Docker image for InsightPulse ERP, providing:

- **Odoo 18 Community Edition** as the base
- **OCA modules** for Enterprise feature parity
- **Notion-style workspaces** for organizing business workflows
- **Industry packs** for Accounting Firms and Marketing Agencies
- **AI-ready architecture** for Claude/agent-generated delta modules

**No Enterprise code. No IAP dependencies. 100% open source.**

## Quick Start

```bash
# Clone the repository
git clone https://github.com/jgtolentino/odoo-ce.git
cd odoo-ce

# Copy environment template
cp .env.example .env

# Edit with your passwords
nano .env

# Start the stack
docker compose up -d

# Access Odoo
open http://localhost:8069
```

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Nginx (SSL/TLS)                      │
│                 erp.insightpulseai.net                  │
└─────────────────────────┬───────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────┐
│              Odoo 18 CE Container                       │
│  ┌───────────────────────────────────────────────────┐  │
│  │  InsightPulse Modules (ipai_*)                    │  │
│  │  ├── ipai_dev_studio_base                         │  │
│  │  ├── ipai_workspace_core                          │  │
│  │  ├── ipai_industry_accounting_firm                │  │
│  │  ├── ipai_industry_marketing_agency               │  │
│  │  └── ipai_ce_cleaner                              │  │
│  └───────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────┐  │
│  │  OCA Modules (vendored)                           │  │
│  │  ├── web_responsive                               │  │
│  │  ├── web_environment_ribbon                       │  │
│  │  └── ...                                          │  │
│  └───────────────────────────────────────────────────┘  │
└─────────────────────────┬───────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────┐
│              PostgreSQL 16                              │
│              (or Supabase)                              │
└─────────────────────────────────────────────────────────┘
```

## Modules

### Core Modules

| Module | Description | Application |
|--------|-------------|-------------|
| `ipai_dev_studio_base` | CE/OCA Studio-equivalent dev stack | No |
| `ipai_workspace_core` | Notion-style workspace model | Yes |
| `ipai_ce_cleaner` | Enterprise/IAP removal | No (auto) |

### Industry Packs

| Module | Description | Application |
|--------|-------------|-------------|
| `ipai_industry_accounting_firm` | Client workspaces, closing dates | No |
| `ipai_industry_marketing_agency` | Brand & campaign workspaces | No |

## Workspace Types

The `ipai.workspace` model supports four types:

1. **Generic** - General-purpose workspaces
2. **Accounting Client** - Per-client engagement tracking
3. **Marketing Brand** - Brand management and retainers
4. **Marketing Campaign** - Campaign execution and budgets

## Development

### Two-Workflow Strategy

**Development (Volume Mounts)**
```bash
# Use docker-compose.dev.yml for development
docker compose -f docker-compose.dev.yml up -d

# Edit code locally, see changes immediately
# Update module: docker exec odoo18_ce_app odoo -d DB -u MODULE
```

**Deployment (Immutable Images)**
```bash
# Build versioned image
docker build -t ghcr.io/jgtolentino/odoo-ce:v1.0.0 .

# Deploy with baked modules
docker compose up -d
```

### Creating Delta Modules

Follow the **Config → OCA → Add-on → Custom** rule:

1. Try configuration first
2. Check if OCA module exists
3. Create delta add-on (`_inherit` existing models)
4. Full custom module only as last resort

```bash
# Create new module
mkdir ipai_addons/ipai_my_feature
# Add __manifest__.py, models/, views/, security/
```

### Module Naming Convention

- All modules: `ipai_<domain>` (e.g., `ipai_expense_ocr`)
- Delta add-ons: `ipai_<domain>_delta_<feature>`
- Industry packs: `ipai_industry_<vertical>`

## CI/CD

The GitHub Actions workflow:

1. **Build** - Multi-arch Docker image (amd64, arm64)
2. **Test** - Smoke tests (40+ checks)
3. **Security** - Trivy vulnerability scan
4. **Deploy** - Push to GHCR and DigitalOcean

```yaml
# Trigger deployment
git tag v1.0.0
git push origin v1.0.0
```

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DB_HOST` | `db` | PostgreSQL host |
| `DB_PORT` | `5432` | PostgreSQL port |
| `DB_USER` | `odoo` | Database user |
| `DB_PASSWORD` | - | Database password (required) |
| `DB_NAME` | `odoo18_ce` | Database name |
| `ADMIN_PASSWORD` | - | Odoo admin password (required) |
| `WORKERS` | `4` | Odoo workers (0 for dev) |
| `AUTO_UPGRADE` | `false` | Auto-upgrade modules on start |

### Odoo Configuration

Key settings in `config/odoo.conf`:

```ini
addons_path = /odoo/ipai_addons,/odoo/oca_addons,/odoo/addons
workers = 4
proxy_mode = True
list_db = False
```

## Cost Savings

| Enterprise Feature | Our Solution | Annual Savings |
|-------------------|--------------|----------------|
| Odoo Enterprise | Odoo CE + OCA | $4,728 |
| SAP Concur | ipai_payment_payout | $15,000 |
| Tableau/Power BI | Apache Superset | $8,400 |
| SAP Ariba | ipai_internal_shop | $12,000 |

**Total potential savings: $40,000+/year**

## License

- **Odoo CE**: LGPL-3
- **OCA Modules**: AGPL-3
- **InsightPulse Modules**: LGPL-3

## Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/my-feature`)
3. Follow CLAUDE.md guidelines
4. Submit PR with module strategy explanation

## Support

- **Documentation**: [docs/](docs/)
- **Issues**: [GitHub Issues](https://github.com/jgtolentino/odoo-ce/issues)
- **Production**: https://erp.insightpulseai.net

---

**InsightPulseAI** - Enterprise ERP without Enterprise pricing.

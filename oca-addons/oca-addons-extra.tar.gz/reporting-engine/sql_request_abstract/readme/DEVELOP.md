This module add the 'pgsql' mode syntax for the ace widget. (the ace
widget is used in odoo web module, but only with the xml and python
mode).

The file is a copy of the file present here
(<https://github.com/ajaxorg/ace-builds/blob/v1.12.3/src/mode-pgsql.js>
(Release 18 Oct 2022)

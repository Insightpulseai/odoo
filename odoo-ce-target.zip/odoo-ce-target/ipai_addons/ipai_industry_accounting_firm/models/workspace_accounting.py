# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Accounting Firm Workspace Extension
# =============================================================================

from odoo import api, fields, models, _
from datetime import date, timedelta


class IpaiWorkspaceAccounting(models.Model):
    """
    Extend workspace with accounting firm-specific fields.
    
    Adds fields for managing client engagements:
    - Link to engagement project
    - Link to analytic account
    - Next closing date tracking
    """
    
    _inherit = "ipai.workspace"

    # -------------------------------------------------------------------------
    # Accounting-Specific Fields
    # -------------------------------------------------------------------------
    accounting_project_id = fields.Many2one(
        comodel_name="project.project",
        string="Engagement Project",
        domain="[('company_id', '=', company_id)]",
        tracking=True,
        help="Primary project for this client engagement.",
    )
    
    analytic_account_id = fields.Many2one(
        comodel_name="account.analytic.account",
        string="Analytic Account",
        domain="[('company_id', '=', company_id)]",
        tracking=True,
        help="Analytic account for tracking engagement costs and revenue.",
    )
    
    next_closing_date = fields.Date(
        string="Next Closing Date",
        tracking=True,
        help="Next month-end, quarter-end, or year-end closing deadline.",
    )
    
    closing_type = fields.Selection(
        selection=[
            ("monthly", "Monthly"),
            ("quarterly", "Quarterly"),
            ("annual", "Annual"),
        ],
        string="Closing Type",
        default="monthly",
        help="Type of recurring closing for this client.",
    )
    
    days_until_closing = fields.Integer(
        string="Days Until Closing",
        compute="_compute_days_until_closing",
        help="Number of days until the next closing date.",
    )
    
    engagement_start_date = fields.Date(
        string="Engagement Start",
        help="Date when the client engagement began.",
    )
    
    fiscal_year_end_month = fields.Selection(
        selection=[
            ("1", "January"),
            ("2", "February"),
            ("3", "March"),
            ("4", "April"),
            ("5", "May"),
            ("6", "June"),
            ("7", "July"),
            ("8", "August"),
            ("9", "September"),
            ("10", "October"),
            ("11", "November"),
            ("12", "December"),
        ],
        string="Fiscal Year End",
        default="12",
        help="Month when the client's fiscal year ends.",
    )
    
    tax_id_number = fields.Char(
        string="Tax ID / TIN",
        help="Client's tax identification number (TIN for Philippines, EIN for US, etc.).",
    )
    
    # -------------------------------------------------------------------------
    # Related Fields from Linked Records
    # -------------------------------------------------------------------------
    task_count = fields.Integer(
        string="Open Tasks",
        compute="_compute_task_count",
    )
    
    invoice_count = fields.Integer(
        string="Invoices",
        compute="_compute_invoice_count",
    )

    # -------------------------------------------------------------------------
    # Computed Fields
    # -------------------------------------------------------------------------
    @api.depends("next_closing_date")
    def _compute_days_until_closing(self):
        """Calculate days remaining until next closing."""
        today = date.today()
        for workspace in self:
            if workspace.next_closing_date:
                delta = workspace.next_closing_date - today
                workspace.days_until_closing = delta.days
            else:
                workspace.days_until_closing = 0
    
    def _compute_task_count(self):
        """Count open tasks in the engagement project."""
        for workspace in self:
            if workspace.accounting_project_id:
                workspace.task_count = self.env["project.task"].search_count([
                    ("project_id", "=", workspace.accounting_project_id.id),
                    ("stage_id.fold", "=", False),
                ])
            else:
                workspace.task_count = 0
    
    def _compute_invoice_count(self):
        """Count invoices linked to the partner."""
        for workspace in self:
            if workspace.partner_id:
                workspace.invoice_count = self.env["account.move"].search_count([
                    ("partner_id", "=", workspace.partner_id.id),
                    ("move_type", "in", ["out_invoice", "out_refund"]),
                ])
            else:
                workspace.invoice_count = 0

    # -------------------------------------------------------------------------
    # Actions
    # -------------------------------------------------------------------------
    def action_view_project_tasks(self):
        """Open tasks for the engagement project."""
        self.ensure_one()
        if not self.accounting_project_id:
            return {"type": "ir.actions.act_window_close"}
        
        return {
            "type": "ir.actions.act_window",
            "name": _("Engagement Tasks"),
            "res_model": "project.task",
            "view_mode": "kanban,tree,form",
            "domain": [("project_id", "=", self.accounting_project_id.id)],
            "context": {
                "default_project_id": self.accounting_project_id.id,
            },
        }
    
    def action_view_invoices(self):
        """Open invoices for the client."""
        self.ensure_one()
        if not self.partner_id:
            return {"type": "ir.actions.act_window_close"}
        
        return {
            "type": "ir.actions.act_window",
            "name": _("Client Invoices"),
            "res_model": "account.move",
            "view_mode": "tree,form",
            "domain": [
                ("partner_id", "=", self.partner_id.id),
                ("move_type", "in", ["out_invoice", "out_refund"]),
            ],
        }
    
    def action_schedule_closing(self):
        """Create calendar event for the closing date."""
        self.ensure_one()
        if not self.next_closing_date:
            return {"type": "ir.actions.act_window_close"}
        
        return {
            "type": "ir.actions.act_window",
            "name": _("Schedule Closing"),
            "res_model": "calendar.event",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_name": f"{self.name} - {self.closing_type.title()} Closing",
                "default_start": self.next_closing_date,
                "default_stop": self.next_closing_date,
                "default_allday": True,
                "default_partner_ids": [(6, 0, self.member_ids.partner_id.ids)],
            },
        }
    
    def action_advance_closing_date(self):
        """Advance the closing date to the next period."""
        for workspace in self:
            if not workspace.next_closing_date:
                continue
            
            current = workspace.next_closing_date
            
            if workspace.closing_type == "monthly":
                # Move to first day of next month
                if current.month == 12:
                    new_date = date(current.year + 1, 1, current.day)
                else:
                    new_date = date(current.year, current.month + 1, current.day)
            
            elif workspace.closing_type == "quarterly":
                # Move forward 3 months
                new_month = current.month + 3
                new_year = current.year
                if new_month > 12:
                    new_month -= 12
                    new_year += 1
                new_date = date(new_year, new_month, current.day)
            
            else:  # annual
                new_date = date(current.year + 1, current.month, current.day)
            
            workspace.next_closing_date = new_date

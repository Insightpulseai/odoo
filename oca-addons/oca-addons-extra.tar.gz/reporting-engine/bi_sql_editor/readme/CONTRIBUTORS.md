- Sylvain LE GAL (<https://twitter.com/legalsylvain>)

- Richard deMeester, WilldooIT (<http://www.willdooit.com/>)

- David James, WilldooIT (<http://www.willdooit.com/>)

- Guillem Casassas <guillem.casassas@forgeflow.com>

- Thien Vo <thienvh@trobz.com>

- This module is highly inspired by the work of
  - Onestein: (<http://www.onestein.nl/>) Module:
    OCA/server-tools/bi_view_editor. Link:
    <https://github.com/OCA/reporting-engine/tree/9.0/bi_view_editor>
  - Anybox: (<https://anybox.fr/>) Module :
    OCA/server-tools/materialized_sql_view link:
    <https://github.com/OCA/server-tools/pull/110>
  - GRAP, Groupement Régional Alimentaire de Proximité:
    (<http://www.grap.coop/>) Module:
    grap/odoo-addons-misc/pos_sale_reporting link:
    <https://github.com/grap/odoo-addons-misc/tree/7.0/pos_sale_reporting>

# ipai_semantics_bridge

Minimal Odoo bridge to Supabase OSI-like semantic functions.

## Supabase functions
- semantic-import-osi (POST)
- semantic-export-osi (GET)
- semantic-query (POST, skeleton)

## Runtime env (preferred)
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY

Fallback params:
- ipai.semantics.supabase_url
- ipai.semantics.bearer_token
- ipai.semantics.default_asset_fqdn

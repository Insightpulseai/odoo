// Supabase Edge Function: semantic-query
// Purpose: Execute an agent-safe query against a semantic model.
// This is a SKELETON: it returns a resolved "query plan" and placeholders.
// You can wire the executor to:
// - Supabase SQL (rpc that applies safe DSL)
// - Superset Dataset API (preferred if you want Superset as execution engine)
//
// POST /functions/v1/semantic-query
// Authorization: Bearer <token>
// Body: {
//   "asset_fqdn": "...",
//   "model_name": "default",
//   "metrics": ["revenue"],
//   "dimensions": ["day"],
//   "filters": [{"dimension":"region","op":"eq","value":"NCR"}],
//   "time_range": {"from":"2025-01-01","to":"2025-12-31"},
//   "limit": 1000
// }

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

function json(res: unknown, status = 200) {
  return new Response(JSON.stringify(res), { status, headers: { "content-type": "application/json; charset=utf-8" }});
}
function requireEnv(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

serve(async (req) => {
  try {
    if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
    const auth = req.headers.get("authorization") || "";
    if (!auth.toLowerCase().startsWith("bearer ")) return json({ error: "Missing bearer token" }, 401);

    const SUPABASE_URL = requireEnv("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = requireEnv("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

    const body = await req.json().catch(() => ({}));
    const asset_fqdn = body?.asset_fqdn as string;
    const model_name = body?.model_name || "default";
    const metrics = body?.metrics || [];
    const dimensions = body?.dimensions || [];
    const filters = body?.filters || [];
    const time_range = body?.time_range || null;
    const limit = body?.limit || 1000;

    if (!asset_fqdn) return json({ error: "asset_fqdn required" }, 400);

    // Load semantic model
    const { data: assets, error: aErr } = await supabase.from("catalog.assets").select("asset_id,fqdn").eq("fqdn", asset_fqdn).limit(1);
    if (aErr) return json({ error: aErr.message, details: aErr }, 500);
    const asset = assets?.[0];
    if (!asset) return json({ error: "asset not found" }, 404);

    const { data: sms, error: smErr } = await supabase.from("catalog.semantic_models").select("*").eq("asset_id", asset.asset_id).eq("name", model_name).limit(1);
    if (smErr) return json({ error: smErr.message, details: smErr }, 500);
    const sm = sms?.[0];
    if (!sm) return json({ error: "semantic model not found" }, 404);

    const { data: dims, error: dErr } = await supabase.from("catalog.semantic_dimensions").select("*").eq("semantic_model_id", sm.semantic_model_id);
    if (dErr) return json({ error: dErr.message, details: dErr }, 500);
    const { data: mets, error: mErr } = await supabase.from("catalog.semantic_metrics").select("*").eq("semantic_model_id", sm.semantic_model_id);
    if (mErr) return json({ error: mErr.message, details: mErr }, 500);

    // Validate requested dims/mets exist
    const dimSet = new Set((dims || []).map((d:any)=>d.name));
    const metSet = new Set((mets || []).map((m:any)=>m.name));

    for (const d of dimensions) if (!dimSet.has(d)) return json({ error: `Unknown dimension: ${d}` }, 400);
    for (const m of metrics) if (!metSet.has(m)) return json({ error: `Unknown metric: ${m}` }, 400);

    // Return a plan (executor implementation is next step)
    const plan = {
      asset_fqdn,
      model_name,
      resolved: {
        dimensions: (dims || []).filter((d:any)=>dimensions.includes(d.name)).map((d:any)=>({ name:d.name, column_ref:d.column_ref, is_time:d.is_time })),
        metrics: (mets || []).filter((m:any)=>metrics.includes(m.name)).map((m:any)=>({ name:m.name, metric_type:m.metric_type, expression:m.expression })),
        filters,
        time_range,
        limit
      },
      executor: "UNIMPLEMENTED",
      notes: [
        "Wire executor to a safe DSL -> SQL generator (server-side) OR Superset Dataset API.",
        "Never accept raw SQL from the client; only semantic objects + whitelisted ops."
      ]
    };

    return json({ ok: true, plan, rows: [], columns: [] }, 200);
  } catch (e) {
    return json({ error: String((e as any)?.message || e) }, 500);
  }
});

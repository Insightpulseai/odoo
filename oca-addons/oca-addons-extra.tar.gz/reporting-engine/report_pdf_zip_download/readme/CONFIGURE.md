To enable the ZIP file feature, please check the 'Zip Download' option
under the 'Advanced Properties' tab for the specific report.

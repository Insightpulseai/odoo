To use this module, you need to:

1.  Go to 'Dashboards \> SQL Reports'
2.  Select the desired report

> ![usage-image1](../static/description/05_reporting_pivot.png)

- You can switch to 'Graph' or 'tree' views as any report.

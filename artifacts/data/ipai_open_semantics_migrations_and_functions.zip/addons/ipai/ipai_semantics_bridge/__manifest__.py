{
  "name": "IPAI Semantics Bridge",
  "summary": "Define/export/import OSI-like semantic models for Odoo/Supabase assets via Edge Functions.",
  "version": "18.0.1.0.0",
  "category": "Technical",
  "license": "AGPL-3",
  "author": "InsightPulseAI",
  "depends": ["base", "web"],
  "data": [
    "data/ir_cron.xml"
  ],
  "assets": {},
  "installable": true,
  "application": false
}

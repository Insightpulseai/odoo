-- IPAI Open Semantics (OSI-style) extension for Supabase catalog.*
-- Adds semantic models, metrics, dimensions, relationships, exports.
-- Depends on catalog schema existing (catalog.assets etc).

begin;

create schema if not exists catalog;

do $$
begin
  if not exists (select 1 from pg_type t join pg_namespace n on n.oid=t.typnamespace
                 where n.nspname='catalog' and t.typname='semantic_status') then
    create type catalog.semantic_status as enum ('draft','certified','deprecated');
  end if;

  if not exists (select 1 from pg_type t join pg_namespace n on n.oid=t.typnamespace
                 where n.nspname='catalog' and t.typname='metric_type') then
    create type catalog.metric_type as enum ('sum','count','count_distinct','avg','min','max','ratio','custom');
  end if;

  if not exists (select 1 from pg_type t join pg_namespace n on n.oid=t.typnamespace
                 where n.nspname='catalog' and t.typname='join_type') then
    create type catalog.join_type as enum ('inner','left','right','full');
  end if;
end $$;

create table if not exists catalog.semantic_models (
  semantic_model_id uuid primary key default gen_random_uuid(),
  asset_id uuid not null references catalog.assets(asset_id) on delete cascade,
  name text not null,
  label text null,
  description text null,
  primary_entity text null,
  grain text null,
  default_time_column text null,
  version text not null default '1.0.0',
  status catalog.semantic_status not null default 'draft',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

do $$
begin
  if not exists (select 1 from pg_indexes where schemaname='catalog' and indexname='semantic_models_asset_name_ux') then
    create unique index semantic_models_asset_name_ux on catalog.semantic_models(asset_id, name);
  end if;
end $$;

create index if not exists semantic_models_status_idx on catalog.semantic_models(status);

create table if not exists catalog.semantic_dimensions (
  dimension_id uuid primary key default gen_random_uuid(),
  semantic_model_id uuid not null references catalog.semantic_models(semantic_model_id) on delete cascade,
  name text not null,
  label text null,
  description text null,
  column_ref text not null,
  data_type text null,
  is_time boolean not null default false,
  hierarchy_key text null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

do $$
begin
  if not exists (select 1 from pg_indexes where schemaname='catalog' and indexname='semantic_dimensions_ux') then
    create unique index semantic_dimensions_ux on catalog.semantic_dimensions(semantic_model_id, name);
  end if;
end $$;

create table if not exists catalog.semantic_metrics (
  metric_id uuid primary key default gen_random_uuid(),
  semantic_model_id uuid not null references catalog.semantic_models(semantic_model_id) on delete cascade,
  name text not null,
  label text null,
  description text null,
  metric_type catalog.metric_type not null default 'custom',
  -- expression is a SAFE DSL you control (e.g., "sum(column)" or "ratio(m1,m2)")
  expression text not null,
  format text null,
  unit text null,
  owner text null,
  certified boolean not null default false,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

do $$
begin
  if not exists (select 1 from pg_indexes where schemaname='catalog' and indexname='semantic_metrics_ux') then
    create unique index semantic_metrics_ux on catalog.semantic_metrics(semantic_model_id, name);
  end if;
end $$;

create table if not exists catalog.semantic_relationships (
  relationship_id uuid primary key default gen_random_uuid(),
  from_semantic_model_id uuid not null references catalog.semantic_models(semantic_model_id) on delete cascade,
  to_semantic_model_id uuid not null references catalog.semantic_models(semantic_model_id) on delete cascade,
  join_type catalog.join_type not null default 'left',
  on_clause jsonb not null default '[]'::jsonb, -- list of {"from":"col","to":"col"}
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists semantic_relationships_from_idx on catalog.semantic_relationships(from_semantic_model_id);
create index if not exists semantic_relationships_to_idx on catalog.semantic_relationships(to_semantic_model_id);

create table if not exists catalog.semantic_exports (
  export_id uuid primary key default gen_random_uuid(),
  semantic_model_id uuid not null references catalog.semantic_models(semantic_model_id) on delete cascade,
  export_format text not null default 'osi_yaml',
  content text not null,
  content_sha256 text not null,
  created_at timestamptz not null default now()
);

create index if not exists semantic_exports_model_idx on catalog.semantic_exports(semantic_model_id);

-- updated_at trigger reuse from catalog._touch_updated_at (created in previous migration)
drop trigger if exists trg_semantic_models_touch on catalog.semantic_models;
create trigger trg_semantic_models_touch
before update on catalog.semantic_models
for each row execute function catalog._touch_updated_at();

-- RLS: read for authenticated; writes via service_role
alter table catalog.semantic_models enable row level security;
alter table catalog.semantic_dimensions enable row level security;
alter table catalog.semantic_metrics enable row level security;
alter table catalog.semantic_relationships enable row level security;
alter table catalog.semantic_exports enable row level security;

drop policy if exists "semantic_models_read" on catalog.semantic_models;
create policy "semantic_models_read" on catalog.semantic_models
for select to authenticated using (true);

drop policy if exists "semantic_dimensions_read" on catalog.semantic_dimensions;
create policy "semantic_dimensions_read" on catalog.semantic_dimensions
for select to authenticated using (true);

drop policy if exists "semantic_metrics_read" on catalog.semantic_metrics;
create policy "semantic_metrics_read" on catalog.semantic_metrics
for select to authenticated using (true);

drop policy if exists "semantic_relationships_read" on catalog.semantic_relationships;
create policy "semantic_relationships_read" on catalog.semantic_relationships
for select to authenticated using (true);

drop policy if exists "semantic_exports_read" on catalog.semantic_exports;
create policy "semantic_exports_read" on catalog.semantic_exports
for select to authenticated using (true);

commit;

# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Workspace Core
# =============================================================================
# Notion-style workspace model for organizing business workflows
# Supports: Accounting clients, Marketing brands/campaigns, Generic workspaces
# =============================================================================
{
    "name": "InsightPulse Workspace Core",
    "version": "18.0.1.0.0",
    "category": "Productivity",
    "summary": "Notion-style workspaces for organizing business workflows",
    "description": """
InsightPulse Workspace Core
===========================

Provides Notion-style workspaces for organizing business workflows in Odoo.
This module is the foundation for industry-specific workspace bundles.

Features
--------
* Generic workspace model (ipai.workspace)
* Workspace types: accounting_client, marketing_brand, marketing_campaign, generic
* Link workspaces to any Odoo record (projects, partners, etc.)
* User membership and ownership management
* Color-coded workspace organization

Workspace Types
---------------
* **Generic**: General-purpose workspace for any use case
* **Accounting Client**: Per-client workspace for accounting firms
* **Marketing Brand**: Per-brand workspace for marketing agencies
* **Marketing Campaign**: Per-campaign workspace for marketing projects

Usage
-----
Install this module to enable the Workspaces menu. Industry-specific bundles
(ipai_industry_accounting_firm, ipai_industry_marketing_agency) extend this
with specialized fields and workflows.

License: LGPL-3
    """,
    "author": "InsightPulseAI",
    "website": "https://erp.insightpulseai.net",
    "license": "LGPL-3",
    "depends": [
        "ipai_dev_studio_base",
        "mail",
    ],
    "data": [
        "security/workspace_security.xml",
        "security/ir.model.access.csv",
        "views/workspace_views.xml",
        "views/workspace_menus.xml",
    ],
    "demo": [
        "demo/workspace_demo.xml",
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
    "images": [
        "static/description/banner.png",
    ],
}

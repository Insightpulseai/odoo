Print a QWeb report (quotation, invoice, purchase order, etc.), and the
value presentation for fields like line quantity, price unit and date
order are adjusted according to the Qweb Field Options configuration.

Note that among matching configuration records, the one with the
strictest condition will be applied.

- The document name result should take the name of the substitution
  report.

Add the possibility to extract data from a sql query toward an excel
file. It is also possible to provide an template excel file for a query.
In this case, the data will be inserted in the specified sheet of the
provided excel file. This is usefull when doing a lot of calculation in
excel and the data is coming from Odoo.

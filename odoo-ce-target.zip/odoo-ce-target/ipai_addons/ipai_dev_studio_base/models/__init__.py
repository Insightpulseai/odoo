# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Development Studio Base Models
# =============================================================================

from . import res_config_settings

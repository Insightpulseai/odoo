# OCA Addons

This directory contains vendored OCA (Odoo Community Association) modules.

## Vendoring Process

1. Identify required OCA modules
2. Clone with specific commit SHA
3. Record in `repos.yaml`

## Example repos.yaml

```yaml
web:
  url: https://github.com/OCA/web
  branch: "18.0"
  commit: abc123def456
  modules: [web_responsive, web_environment_ribbon]

server-tools:
  url: https://github.com/OCA/server-tools
  branch: "18.0"
  commit: def456abc789
  modules: [base_technical_user]
```

## Installation

```bash
# Sparse clone example
git clone --filter=blob:none --sparse https://github.com/OCA/web.git
cd web
git sparse-checkout add web_responsive
git checkout abc123def456
```

## Current Modules

Add vendored modules here as needed per the "18 oca" mapping.

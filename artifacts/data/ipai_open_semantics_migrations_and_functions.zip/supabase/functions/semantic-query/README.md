# semantic-query (skeleton)

Validates semantic query requests and returns a resolved query plan.
Executor wiring is intentionally left unimplemented to keep it safe-by-construction.

## Env
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY

## Request
POST /functions/v1/semantic-query
Authorization: Bearer <token>

Body:
{
  "asset_fqdn":"supabase.ipai.scout.gold_sales_by_day",
  "model_name":"sales",
  "metrics":["revenue"],
  "dimensions":["day"],
  "filters":[{"dimension":"region","op":"eq","value":"NCR"}],
  "time_range":{"from":"2025-01-01","to":"2025-12-31"},
  "limit":1000
}

To use this module, you need to:

1.  go to your report
2.  select a PDF or image to use as watermark. Note that resolutions and
    size must match, otherwise you'll have funny results
3.  You can also fill in an expression that returns the data (base64
    encoded) to be used as watermark

To use the Company watermark, you need to:

1.  go to settings --\> company --\> update info
2.  upload an pdf watermark
3.  go to settings --\> technical --\> reporting --\> reports
4.  Select the report where you want to use it.
5.  On the 'Advanced Properties' tab of the notebook check 'use company
    watermark'

\### Demo And demo report is available (if you have demo data installed)
on the users form view.

1.  go to Configuration --\> users
2.  Select an users
3.  Click the print button --\> Watermark Demo report.

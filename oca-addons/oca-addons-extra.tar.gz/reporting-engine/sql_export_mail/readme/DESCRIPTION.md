Allow to send the result of a query (made with the module sql_export) by
mail.

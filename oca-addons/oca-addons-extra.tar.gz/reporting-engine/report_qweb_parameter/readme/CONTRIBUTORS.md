- Enric Tobella \<<etobella@creublanca.es>\>

- [Tecnativa](https://www.tecnativa.com):

  > - Carlos Roca

- Iván Antón \<<ozono@ozonomultimedia.com>\>

- [Sygel Technology](https://www.sygel.es):

  > - Valentin Vinagre

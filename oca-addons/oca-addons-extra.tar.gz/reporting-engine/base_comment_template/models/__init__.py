from . import base_comment_template
from . import comment_template
from . import ir_model
from . import res_partner

This module adds a context variable to reports. A possible use for this
context could be hiding some fields or many other configuration options.

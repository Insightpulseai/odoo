To configure the use of an external database, you need to edit the main
configuration file of your instance and add the external database
configuration with following keys : \* external_db_user \*
external_db_password \* external_db_name \* external_db_host \*
external_db_port

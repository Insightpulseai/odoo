# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Development Studio Base
# =============================================================================

from . import models


def post_init_hook(env):
    """
    Post-installation hook to configure development environment.
    
    Actions:
    - Set development-friendly system parameters
    - Disable IAP services if present
    - Configure default user preferences
    """
    # Set system parameters for CE/OCA baseline
    env["ir.config_parameter"].sudo().set_param(
        "ipai.dev_studio_base.installed", "True"
    )
    
    # Log installation
    env["ir.logging"].sudo().create({
        "name": "ipai_dev_studio_base",
        "type": "server",
        "level": "INFO",
        "message": "InsightPulse Dev Studio Base installed successfully",
        "path": "ipai_dev_studio_base",
        "func": "post_init_hook",
        "line": "1",
    })

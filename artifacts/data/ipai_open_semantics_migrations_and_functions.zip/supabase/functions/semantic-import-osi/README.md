# semantic-import-osi

Upserts OSI-like semantic definitions into `catalog.semantic_*`.

## Env
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY

## Request (JSON recommended)
POST /functions/v1/semantic-import-osi
Authorization: Bearer <token>

Body:
{
  "asset_fqdn": "supabase.ipai.scout.gold_sales_by_day",
  "semantic_model": { "name": "sales", "label": "Sales", "status": "draft" },
  "dimensions": [ { "name":"day", "column_ref":"day", "is_time": true } ],
  "metrics": [ { "name":"revenue", "metric_type":"sum", "expression":"sum(revenue)" } ],
  "export": { "format":"osi_yaml", "content":"<optional yaml snapshot>" }
}

# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Workspace Model
# =============================================================================
# Notion-style workspace for organizing business workflows
# =============================================================================

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class IpaiWorkspace(models.Model):
    """
    Notion-style workspace for organizing business workflows.
    
    A workspace can be linked to any Odoo record and serves as a container
    for organizing related work, documents, and team collaboration.
    """
    
    _name = "ipai.workspace"
    _description = "InsightPulse Workspace"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "sequence, name"
    _rec_name = "name"

    # -------------------------------------------------------------------------
    # Core Fields
    # -------------------------------------------------------------------------
    name = fields.Char(
        string="Workspace Name",
        required=True,
        tracking=True,
        index=True,
    )
    
    workspace_type = fields.Selection(
        selection=[
            ("generic", "Generic"),
            ("accounting_client", "Accounting Client"),
            ("marketing_brand", "Marketing Brand"),
            ("marketing_campaign", "Marketing Campaign"),
        ],
        string="Type",
        default="generic",
        required=True,
        tracking=True,
        help="Type of workspace determines available features and fields.",
    )
    
    description = fields.Html(
        string="Description",
        sanitize=True,
        strip_style=False,
        help="Rich text description of the workspace purpose and contents.",
    )
    
    # -------------------------------------------------------------------------
    # Organization
    # -------------------------------------------------------------------------
    sequence = fields.Integer(
        string="Sequence",
        default=10,
        help="Order in which workspaces appear in lists.",
    )
    
    color = fields.Integer(
        string="Color Index",
        default=0,
        help="Color for kanban and calendar views.",
    )
    
    active = fields.Boolean(
        string="Active",
        default=True,
        tracking=True,
        help="Inactive workspaces are hidden but not deleted.",
    )
    
    # -------------------------------------------------------------------------
    # Ownership & Membership
    # -------------------------------------------------------------------------
    owner_id = fields.Many2one(
        comodel_name="res.users",
        string="Owner",
        default=lambda self: self.env.user,
        required=True,
        tracking=True,
        index=True,
        help="User who owns and administers this workspace.",
    )
    
    member_ids = fields.Many2many(
        comodel_name="res.users",
        relation="ipai_workspace_user_rel",
        column1="workspace_id",
        column2="user_id",
        string="Members",
        help="Users who have access to this workspace.",
    )
    
    member_count = fields.Integer(
        string="Member Count",
        compute="_compute_member_count",
        store=True,
    )
    
    # -------------------------------------------------------------------------
    # Linked Record (polymorphic)
    # -------------------------------------------------------------------------
    partner_id = fields.Many2one(
        comodel_name="res.partner",
        string="Related Partner",
        tracking=True,
        index=True,
        help="Primary contact or company associated with this workspace.",
    )
    
    res_model = fields.Char(
        string="Related Model",
        index=True,
        help="Technical name of the linked model (e.g., 'project.project').",
    )
    
    res_id = fields.Integer(
        string="Related Record ID",
        index=True,
        help="Database ID of the linked record.",
    )
    
    res_name = fields.Char(
        string="Related Record",
        compute="_compute_res_name",
        help="Display name of the linked record.",
    )
    
    # -------------------------------------------------------------------------
    # Company (multi-company support)
    # -------------------------------------------------------------------------
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        default=lambda self: self.env.company,
        required=True,
        index=True,
    )

    # -------------------------------------------------------------------------
    # Computed Fields
    # -------------------------------------------------------------------------
    @api.depends("member_ids")
    def _compute_member_count(self):
        """Compute the number of workspace members."""
        for workspace in self:
            workspace.member_count = len(workspace.member_ids)
    
    @api.depends("res_model", "res_id")
    def _compute_res_name(self):
        """Compute display name of linked record."""
        for workspace in self:
            if workspace.res_model and workspace.res_id:
                try:
                    record = self.env[workspace.res_model].browse(workspace.res_id)
                    workspace.res_name = record.display_name if record.exists() else False
                except Exception:
                    workspace.res_name = False
            else:
                workspace.res_name = False

    # -------------------------------------------------------------------------
    # Constraints
    # -------------------------------------------------------------------------
    @api.constrains("res_model", "res_id")
    def _check_res_model_id(self):
        """Ensure res_model and res_id are both set or both empty."""
        for workspace in self:
            if bool(workspace.res_model) != bool(workspace.res_id):
                raise ValidationError(
                    _("Both 'Related Model' and 'Related Record ID' must be set together.")
                )

    _sql_constraints = [
        (
            "name_company_uniq",
            "UNIQUE(name, company_id)",
            "Workspace name must be unique per company.",
        ),
    ]

    # -------------------------------------------------------------------------
    # CRUD Methods
    # -------------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        """Create workspaces with auto-member assignment."""
        workspaces = super().create(vals_list)
        for workspace in workspaces:
            # Auto-add owner as member if not already
            if workspace.owner_id not in workspace.member_ids:
                workspace.member_ids = [(4, workspace.owner_id.id)]
        return workspaces
    
    def write(self, vals):
        """Update workspaces with owner sync."""
        result = super().write(vals)
        # If owner changed, ensure they're a member
        if "owner_id" in vals:
            for workspace in self:
                if workspace.owner_id not in workspace.member_ids:
                    workspace.member_ids = [(4, workspace.owner_id.id)]
        return result

    # -------------------------------------------------------------------------
    # Actions
    # -------------------------------------------------------------------------
    def action_open_linked_record(self):
        """Open the linked record in a form view."""
        self.ensure_one()
        if not self.res_model or not self.res_id:
            return {"type": "ir.actions.act_window_close"}
        
        return {
            "type": "ir.actions.act_window",
            "res_model": self.res_model,
            "res_id": self.res_id,
            "view_mode": "form",
            "target": "current",
        }
    
    def action_add_members(self):
        """Open wizard to add members."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Add Members"),
            "res_model": "res.users",
            "view_mode": "tree",
            "domain": [("id", "not in", self.member_ids.ids)],
            "target": "new",
            "context": {
                "default_workspace_id": self.id,
            },
        }
    
    def action_archive(self):
        """Archive the workspace."""
        self.write({"active": False})
    
    def action_unarchive(self):
        """Unarchive the workspace."""
        self.write({"active": True})

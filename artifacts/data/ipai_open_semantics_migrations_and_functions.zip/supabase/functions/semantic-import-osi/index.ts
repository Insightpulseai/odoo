// Supabase Edge Function: semantic-import-osi
// Purpose: Upsert semantic models/metrics/dimensions from an OSI-like payload.
//
// Recommended input is JSON (vendor-neutral).
// {
//   "asset_fqdn": "supabase.ipai.scout.gold_sales_by_day",
//   "semantic_model": { "name": "sales", "label": "Sales", "status": "draft", ... },
//   "dimensions": [ { "name":"day", "column_ref":"day", "is_time": true }, ... ],
//   "metrics": [ { "name":"revenue", "metric_type":"sum", "expression":"sum(revenue)" }, ... ],
//   "relationships": [ { "to_asset_fqdn":"...", "join_type":"left", "on":[{"from":"store_id","to":"store_id"}] } ],
//   "export": { "format":"osi_yaml", "content":"<yaml string optional>" }
// }
//
// Auth: Bearer token required. Uses service_role key to write.

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

function json(res: unknown, status = 200) {
  return new Response(JSON.stringify(res), { status, headers: { "content-type": "application/json; charset=utf-8" }});
}

function requireEnv(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

type Dim = {
  name: string;
  column_ref: string;
  label?: string;
  description?: string;
  data_type?: string;
  is_time?: boolean;
  hierarchy_key?: string;
  metadata?: Record<string, unknown>;
};

type Met = {
  name: string;
  expression: string;
  metric_type?: string;
  label?: string;
  description?: string;
  format?: string;
  unit?: string;
  owner?: string;
  certified?: boolean;
  metadata?: Record<string, unknown>;
};

serve(async (req) => {
  try {
    if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
    const auth = req.headers.get("authorization") || "";
    if (!auth.toLowerCase().startsWith("bearer ")) return json({ error: "Missing bearer token" }, 401);

    const SUPABASE_URL = requireEnv("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = requireEnv("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

    const body = await req.json().catch(() => ({}));
    const asset_fqdn = body?.asset_fqdn as string;
    if (!asset_fqdn) return json({ error: "asset_fqdn required" }, 400);

    // Ensure asset exists
    const assetUpsert = {
      asset_type: "view",
      system: "supabase",
      fqdn: asset_fqdn,
      title: body?.semantic_model?.label || body?.semantic_model?.name || asset_fqdn,
      description: body?.semantic_model?.description ?? null,
      owner: body?.semantic_model?.owner ?? null,
      tags: body?.semantic_model?.tags ?? [],
      uri: body?.semantic_model?.uri ?? null,
      metadata: body?.asset_metadata ?? {},
    };

    const { data: assetRows, error: assetErr } = await supabase
      .from("catalog.assets")
      .upsert(assetUpsert, { onConflict: "fqdn" })
      .select("asset_id,fqdn");

    if (assetErr) return json({ error: assetErr.message, details: assetErr }, 500);
    const asset_id = assetRows?.[0]?.asset_id as string;
    if (!asset_id) return json({ error: "asset upsert failed" }, 500);

    const sm = body?.semantic_model || {};
    const smRow = {
      asset_id,
      name: sm?.name || "default",
      label: sm?.label ?? null,
      description: sm?.description ?? null,
      primary_entity: sm?.primary_entity ?? null,
      grain: sm?.grain ?? null,
      default_time_column: sm?.default_time_column ?? null,
      version: sm?.version ?? "1.0.0",
      status: sm?.status ?? "draft",
      metadata: sm?.metadata ?? {},
    };

    const { data: smRows, error: smErr } = await supabase
      .from("catalog.semantic_models")
      .upsert(smRow, { onConflict: "asset_id,name" })
      .select("semantic_model_id,asset_id,name");

    if (smErr) return json({ error: smErr.message, details: smErr }, 500);
    const semantic_model_id = smRows?.[0]?.semantic_model_id as string;

    const dims = (body?.dimensions || []) as Dim[];
    const mets = (body?.metrics || []) as Met[];

    if (dims.length) {
      const dimRows = dims.map((d) => ({
        semantic_model_id,
        name: d.name,
        label: d.label ?? null,
        description: d.description ?? null,
        column_ref: d.column_ref,
        data_type: d.data_type ?? null,
        is_time: d.is_time ?? false,
        hierarchy_key: d.hierarchy_key ?? null,
        metadata: d.metadata ?? {},
      }));
      const { error: dimErr } = await supabase.from("catalog.semantic_dimensions").upsert(dimRows, { onConflict: "semantic_model_id,name" });
      if (dimErr) return json({ error: dimErr.message, details: dimErr }, 500);
    }

    if (mets.length) {
      const metRows = mets.map((m) => ({
        semantic_model_id,
        name: m.name,
        label: m.label ?? null,
        description: m.description ?? null,
        metric_type: m.metric_type ?? "custom",
        expression: m.expression,
        format: m.format ?? null,
        unit: m.unit ?? null,
        owner: m.owner ?? null,
        certified: m.certified ?? false,
        metadata: m.metadata ?? {},
      }));
      const { error: metErr } = await supabase.from("catalog.semantic_metrics").upsert(metRows, { onConflict: "semantic_model_id,name" });
      if (metErr) return json({ error: metErr.message, details: metErr }, 500);
    }

    // Save OSI YAML snapshot if provided
    const exp = body?.export;
    if (exp?.content) {
      const content = String(exp.content);
      const encoder = new TextEncoder();
      const hashBuf = await crypto.subtle.digest("SHA-256", encoder.encode(content));
      const hashArr = Array.from(new Uint8Array(hashBuf));
      const sha = hashArr.map((b) => b.toString(16).padStart(2, "0")).join("");

      const { error: exErr } = await supabase.from("catalog.semantic_exports").insert({
        semantic_model_id,
        export_format: exp?.format || "osi_yaml",
        content,
        content_sha256: sha,
      });
      if (exErr) return json({ error: exErr.message, details: exErr }, 500);
    }

    return json({ ok: true, asset_id, semantic_model_id, dims: dims.length, metrics: mets.length }, 200);
  } catch (e) {
    return json({ error: String((e as any)?.message || e) }, 500);
  }
});

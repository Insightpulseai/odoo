# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError
import os
import json
import logging

_logger = logging.getLogger(__name__)

try:
    import requests
except Exception as e:
    requests = None
    _logger.warning("requests not available: %s", e)


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    ipai_semantics_supabase_url = fields.Char(string="Supabase URL", config_parameter="ipai.semantics.supabase_url")
    ipai_semantics_import_path = fields.Char(string="Semantics Import Path", config_parameter="ipai.semantics.import_path", default="/functions/v1/semantic-import-osi")
    ipai_semantics_export_path = fields.Char(string="Semantics Export Path", config_parameter="ipai.semantics.export_path", default="/functions/v1/semantic-export-osi")
    ipai_semantics_bearer_token = fields.Char(string="Semantics Bearer Token", config_parameter="ipai.semantics.bearer_token")
    ipai_semantics_default_asset_fqdn = fields.Char(
        string="Default Asset FQDN",
        config_parameter="ipai.semantics.default_asset_fqdn",
        default="supabase.ipai.scout.gold_sales_by_day"
    )


class IpaISemanticsBridge(models.AbstractModel):
    _name = "ipai.semantics.bridge"
    _description = "IPAI Semantics Bridge"

    @api.model
    def _get_param(self, k, d=None):
        return self.env["ir.config_parameter"].sudo().get_param(k, d)

    @api.model
    def _env_or_param(self, env_key, param_key, default=None):
        v = os.getenv(env_key)
        return v if v else self._get_param(param_key, default)

    @api.model
    def _supabase_url(self):
        url = self._env_or_param("SUPABASE_URL", "ipai.semantics.supabase_url", "")
        if not url:
            raise UserError(_("Supabase URL not configured"))
        return url.rstrip("/")

    @api.model
    def _token(self):
        token = self._env_or_param("SUPABASE_SERVICE_ROLE_KEY", "ipai.semantics.bearer_token", "")
        if not token:
            raise UserError(_("Bearer token not configured"))
        return token

    @api.model
    def import_osi_payload(self, payload):
        if requests is None:
            raise UserError(_("Python 'requests' not available"))
        endpoint = self._supabase_url() + self._get_param("ipai.semantics.import_path", "/functions/v1/semantic-import-osi")
        resp = requests.post(endpoint, headers={"Authorization": f"Bearer {self._token()}", "Content-Type": "application/json"}, data=json.dumps(payload), timeout=30)
        if resp.status_code >= 400:
            _logger.error("semantic import failed: %s %s", resp.status_code, resp.text)
            raise UserError(_("Semantic import failed (%s)") % resp.status_code)
        return True

    @api.model
    def export_osi(self, asset_fqdn=None, model_name="default", format="both"):
        if requests is None:
            raise UserError(_("Python 'requests' not available"))
        if not asset_fqdn:
            asset_fqdn = self._get_param("ipai.semantics.default_asset_fqdn", "")
        endpoint = self._supabase_url() + self._get_param("ipai.semantics.export_path", "/functions/v1/semantic-export-osi")
        params = {"asset_fqdn": asset_fqdn, "model_name": model_name, "format": format}
        resp = requests.get(endpoint, headers={"Authorization": f"Bearer {self._token()}"}, params=params, timeout=30)
        if resp.status_code >= 400:
            _logger.error("semantic export failed: %s %s", resp.status_code, resp.text)
            raise UserError(_("Semantic export failed (%s)") % resp.status_code)
        return resp.text

    @api.model
    def seed_default_template(self):
        # Seeds a default model for the configured asset fqdn (template example)
        asset_fqdn = self._get_param("ipai.semantics.default_asset_fqdn", "supabase.ipai.scout.gold_sales_by_day")
        payload = {
            "asset_fqdn": asset_fqdn,
            "semantic_model": {"name": "sales", "label": "Sales", "status": "draft", "grain": "day", "default_time_column": "day", "version": "1.0.0"},
            "dimensions": [
                {"name": "day", "label": "Day", "column_ref": "day", "is_time": True, "data_type": "date"},
                {"name": "store_id", "label": "Store", "column_ref": "store_id", "data_type": "text"},
            ],
            "metrics": [
                {"name": "revenue", "label": "Revenue", "metric_type": "sum", "expression": "sum(revenue)", "format": "currency", "unit": "PHP", "certified": False},
            ]
        }
        return self.import_osi_payload(payload)

    @api.model
    def cron_seed_once(self):
        # Safe cron: only seeds if no semantic models exist for the asset
        if requests is None:
            return False
        asset_fqdn = self._get_param("ipai.semantics.default_asset_fqdn", "supabase.ipai.scout.gold_sales_by_day")
        # No direct DB read here (avoid needing Supabase anon key); just attempt import each time.
        # In practice, you should disable after first run.
        try:
            self.seed_default_template()
        except Exception as e:
            _logger.info("seed_default_template skipped/failed: %s", e)
        return True

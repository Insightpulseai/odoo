To use this module, you need to:

1.  Go to 'Actions' / 'Reports'
2.  Select the desired report you want to 'Substitution Rules'
3.  In the substitutions page add a new line
4.  Select the substitution report action
5.  Set a domain to specify when this substitution should happen

When a user calls a report action, the system tries to find the first
substitution in with a domain that matches all records.

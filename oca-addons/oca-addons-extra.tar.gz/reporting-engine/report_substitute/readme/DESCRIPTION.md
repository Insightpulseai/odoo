This module allows you to create substitution rules for report actions.
A typical use case is to replace a standard report by alternative
reports when some conditions are met. For instance, it allows to
configure alternate reports for different companies.

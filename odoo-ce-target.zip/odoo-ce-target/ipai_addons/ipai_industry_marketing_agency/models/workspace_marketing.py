# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Marketing Agency Workspace Extension
# =============================================================================

from odoo import api, fields, models, _
from datetime import date


class IpaiWorkspaceMarketing(models.Model):
    """
    Extend workspace with marketing agency-specific fields.
    
    Adds fields for managing brands and campaigns:
    - Brand management fields (code, guidelines, assets)
    - Campaign management fields (budget, timeline, events)
    """
    
    _inherit = "ipai.workspace"

    # -------------------------------------------------------------------------
    # Brand-Specific Fields (marketing_brand type)
    # -------------------------------------------------------------------------
    brand_code = fields.Char(
        string="Brand Code",
        size=20,
        tracking=True,
        help="Short unique code for the brand (e.g., ACME, TECH01).",
    )
    
    main_project_id = fields.Many2one(
        comodel_name="project.project",
        string="Main Project",
        domain="[('company_id', '=', company_id)]",
        tracking=True,
        help="Primary ongoing project for this brand.",
    )
    
    brand_guidelines = fields.Html(
        string="Brand Guidelines",
        sanitize=True,
        help="Brand guidelines, colors, fonts, and usage rules.",
    )
    
    brand_website = fields.Char(
        string="Brand Website",
        help="Primary website URL for the brand.",
    )
    
    # -------------------------------------------------------------------------
    # Campaign-Specific Fields (marketing_campaign type)
    # -------------------------------------------------------------------------
    campaign_project_id = fields.Many2one(
        comodel_name="project.project",
        string="Campaign Project",
        domain="[('company_id', '=', company_id)]",
        tracking=True,
        help="Project tracking this campaign's deliverables.",
    )
    
    budget_amount = fields.Monetary(
        string="Budget",
        currency_field="currency_id",
        tracking=True,
        help="Total budget allocated for this campaign.",
    )
    
    spent_amount = fields.Monetary(
        string="Spent",
        currency_field="currency_id",
        compute="_compute_spent_amount",
        help="Amount spent so far on this campaign.",
    )
    
    remaining_budget = fields.Monetary(
        string="Remaining",
        currency_field="currency_id",
        compute="_compute_remaining_budget",
        help="Remaining budget for this campaign.",
    )
    
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        default=lambda self: self.env.company.currency_id,
    )
    
    campaign_start_date = fields.Date(
        string="Campaign Start",
        tracking=True,
        help="Start date of the campaign.",
    )
    
    campaign_end_date = fields.Date(
        string="Campaign End",
        tracking=True,
        help="End date of the campaign.",
    )
    
    campaign_status = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("planning", "Planning"),
            ("active", "Active"),
            ("completed", "Completed"),
            ("cancelled", "Cancelled"),
        ],
        string="Campaign Status",
        default="draft",
        tracking=True,
    )
    
    days_remaining = fields.Integer(
        string="Days Remaining",
        compute="_compute_days_remaining",
        help="Days until campaign end date.",
    )
    
    parent_brand_id = fields.Many2one(
        comodel_name="ipai.workspace",
        string="Parent Brand",
        domain="[('workspace_type', '=', 'marketing_brand')]",
        help="Brand this campaign belongs to.",
    )
    
    # -------------------------------------------------------------------------
    # Related Stats
    # -------------------------------------------------------------------------
    lead_count = fields.Integer(
        string="Leads",
        compute="_compute_lead_count",
    )
    
    opportunity_count = fields.Integer(
        string="Opportunities",
        compute="_compute_opportunity_count",
    )
    
    campaign_task_count = fields.Integer(
        string="Tasks",
        compute="_compute_campaign_task_count",
    )

    # -------------------------------------------------------------------------
    # Computed Fields
    # -------------------------------------------------------------------------
    def _compute_spent_amount(self):
        """Calculate spent amount from linked analytic account."""
        for workspace in self:
            # Placeholder - would normally sum from analytic lines
            workspace.spent_amount = 0.0
    
    @api.depends("budget_amount", "spent_amount")
    def _compute_remaining_budget(self):
        """Calculate remaining budget."""
        for workspace in self:
            workspace.remaining_budget = workspace.budget_amount - workspace.spent_amount
    
    @api.depends("campaign_end_date")
    def _compute_days_remaining(self):
        """Calculate days until campaign end."""
        today = date.today()
        for workspace in self:
            if workspace.campaign_end_date:
                delta = workspace.campaign_end_date - today
                workspace.days_remaining = delta.days
            else:
                workspace.days_remaining = 0
    
    def _compute_lead_count(self):
        """Count leads linked to partner."""
        for workspace in self:
            if workspace.partner_id:
                workspace.lead_count = self.env["crm.lead"].search_count([
                    ("partner_id", "=", workspace.partner_id.id),
                    ("type", "=", "lead"),
                ])
            else:
                workspace.lead_count = 0
    
    def _compute_opportunity_count(self):
        """Count opportunities linked to partner."""
        for workspace in self:
            if workspace.partner_id:
                workspace.opportunity_count = self.env["crm.lead"].search_count([
                    ("partner_id", "=", workspace.partner_id.id),
                    ("type", "=", "opportunity"),
                ])
            else:
                workspace.opportunity_count = 0
    
    def _compute_campaign_task_count(self):
        """Count tasks in campaign project."""
        for workspace in self:
            project = workspace.campaign_project_id or workspace.main_project_id
            if project:
                workspace.campaign_task_count = self.env["project.task"].search_count([
                    ("project_id", "=", project.id),
                ])
            else:
                workspace.campaign_task_count = 0

    # -------------------------------------------------------------------------
    # Constraints
    # -------------------------------------------------------------------------
    _sql_constraints = [
        (
            "brand_code_company_uniq",
            "UNIQUE(brand_code, company_id)",
            "Brand code must be unique per company.",
        ),
    ]

    # -------------------------------------------------------------------------
    # Actions
    # -------------------------------------------------------------------------
    def action_view_leads(self):
        """Open leads for this brand/campaign."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Leads"),
            "res_model": "crm.lead",
            "view_mode": "tree,form",
            "domain": [
                ("partner_id", "=", self.partner_id.id),
                ("type", "=", "lead"),
            ],
        }
    
    def action_view_opportunities(self):
        """Open opportunities for this brand/campaign."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Opportunities"),
            "res_model": "crm.lead",
            "view_mode": "kanban,tree,form",
            "domain": [
                ("partner_id", "=", self.partner_id.id),
                ("type", "=", "opportunity"),
            ],
        }
    
    def action_view_campaign_tasks(self):
        """Open tasks for this campaign."""
        self.ensure_one()
        project = self.campaign_project_id or self.main_project_id
        if not project:
            return {"type": "ir.actions.act_window_close"}
        
        return {
            "type": "ir.actions.act_window",
            "name": _("Campaign Tasks"),
            "res_model": "project.task",
            "view_mode": "kanban,tree,form",
            "domain": [("project_id", "=", project.id)],
            "context": {"default_project_id": project.id},
        }
    
    def action_start_campaign(self):
        """Set campaign to active status."""
        self.write({
            "campaign_status": "active",
            "campaign_start_date": self.campaign_start_date or date.today(),
        })
    
    def action_complete_campaign(self):
        """Mark campaign as completed."""
        self.write({
            "campaign_status": "completed",
            "campaign_end_date": self.campaign_end_date or date.today(),
        })

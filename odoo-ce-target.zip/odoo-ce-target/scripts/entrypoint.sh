#!/bin/bash
# =============================================================================
# InsightPulse ERP - Custom Entrypoint
# =============================================================================
# Handles:
#   - Database initialization (first run)
#   - Module installation (-i)
#   - Module upgrades (-u)
#   - Graceful shutdown
# =============================================================================

set -e

# -----------------------------------------------------------------------------
# Environment defaults
# -----------------------------------------------------------------------------
: "${DB_HOST:=db}"
: "${DB_PORT:=5432}"
: "${DB_USER:=odoo}"
: "${DB_PASSWORD:=odoo}"
: "${DB_NAME:=odoo18_ce}"
: "${AUTO_UPGRADE:=false}"
: "${ODOO_INIT_MODULES:=}"
: "${ODOO_UPDATE_MODULES:=}"
: "${WAIT_DB_TIMEOUT:=60}"

# -----------------------------------------------------------------------------
# Logging functions
# -----------------------------------------------------------------------------
log_info() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] [INFO] $*"
}

log_warn() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] [WARN] $*" >&2
}

log_error() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] [ERROR] $*" >&2
}

# -----------------------------------------------------------------------------
# Wait for database to be ready
# -----------------------------------------------------------------------------
wait_for_db() {
    local start_time=$(date +%s)
    local timeout=${WAIT_DB_TIMEOUT}
    
    log_info "Waiting for PostgreSQL at ${DB_HOST}:${DB_PORT}..."
    
    while ! nc -z "${DB_HOST}" "${DB_PORT}" 2>/dev/null; do
        local current_time=$(date +%s)
        local elapsed=$((current_time - start_time))
        
        if [ ${elapsed} -ge ${timeout} ]; then
            log_error "Database connection timeout after ${timeout}s"
            exit 1
        fi
        
        sleep 1
    done
    
    log_info "PostgreSQL is ready"
}

# -----------------------------------------------------------------------------
# Check if database exists and has Odoo tables
# -----------------------------------------------------------------------------
db_initialized() {
    PGPASSWORD="${DB_PASSWORD}" psql -h "${DB_HOST}" -p "${DB_PORT}" -U "${DB_USER}" -d "${DB_NAME}" \
        -c "SELECT 1 FROM ir_module_module LIMIT 1" &>/dev/null
    return $?
}

# -----------------------------------------------------------------------------
# Initialize database with base modules
# -----------------------------------------------------------------------------
init_database() {
    log_info "Initializing database ${DB_NAME}..."
    
    # Base InsightPulse modules to install on fresh DB
    local base_modules="ipai_dev_studio_base,ipai_workspace_core"
    
    # Add user-requested modules
    if [ -n "${ODOO_INIT_MODULES}" ]; then
        base_modules="${base_modules},${ODOO_INIT_MODULES}"
    fi
    
    log_info "Installing modules: ${base_modules}"
    
    odoo -c /etc/odoo/odoo.conf \
        -d "${DB_NAME}" \
        -i "${base_modules}" \
        --stop-after-init \
        --no-http
    
    log_info "Database initialized successfully"
}

# -----------------------------------------------------------------------------
# Upgrade modules (for deployments)
# -----------------------------------------------------------------------------
upgrade_modules() {
    local modules="${1:-}"
    
    if [ -z "${modules}" ]; then
        log_info "No modules to upgrade"
        return 0
    fi
    
    log_info "Upgrading modules: ${modules}"
    
    odoo -c /etc/odoo/odoo.conf \
        -d "${DB_NAME}" \
        -u "${modules}" \
        --stop-after-init \
        --no-http
    
    log_info "Module upgrade completed"
}

# -----------------------------------------------------------------------------
# Main entrypoint logic
# -----------------------------------------------------------------------------
main() {
    # Wait for database
    wait_for_db
    
    # Check if this is a fresh database
    if ! db_initialized; then
        log_info "Fresh database detected, running initialization..."
        init_database
    else
        log_info "Existing database detected"
        
        # Auto-upgrade if enabled
        if [ "${AUTO_UPGRADE}" = "true" ] && [ -n "${ODOO_UPDATE_MODULES}" ]; then
            upgrade_modules "${ODOO_UPDATE_MODULES}"
        fi
    fi
    
    # Start Odoo
    log_info "Starting Odoo..."
    exec odoo -c /etc/odoo/odoo.conf "$@"
}

# -----------------------------------------------------------------------------
# Handle signals for graceful shutdown
# -----------------------------------------------------------------------------
trap 'log_info "Received SIGTERM, shutting down..."; exit 0' SIGTERM
trap 'log_info "Received SIGINT, shutting down..."; exit 0' SIGINT

# -----------------------------------------------------------------------------
# Execute
# -----------------------------------------------------------------------------
main "$@"

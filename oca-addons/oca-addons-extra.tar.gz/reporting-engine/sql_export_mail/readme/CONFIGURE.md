To configure this module, you need to:

1.  Go to the sql query for which you want users to be notified by
    e-mail.
2.  Add users to be notified in the field Users Notified by e-mail.
3.  Click on the button create a cron and then configure the cron to run
    when you want to. If you already have created a cron for another
    query, you can use it again for other queries

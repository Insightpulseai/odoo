This module is an extension of module Mass Editing to support playing onchange before writing.

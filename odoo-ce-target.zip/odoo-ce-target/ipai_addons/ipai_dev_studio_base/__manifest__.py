# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Development Studio Base
# =============================================================================
# CE/OCA equivalent of Odoo Studio - provides technical primitives for dev
# Mandatory dependency for all InsightPulse modules
# =============================================================================
{
    "name": "InsightPulse Dev Studio Base",
    "version": "18.0.1.0.0",
    "category": "Technical",
    "summary": "CE/OCA Studio-equivalent development baseline for InsightPulse",
    "description": """
InsightPulse Development Studio Base
====================================

This module provides the technical primitives and development baseline for 
InsightPulse ERP, serving as the CE/OCA equivalent of Odoo Studio.

Features
--------
* Bundles essential Odoo CE modules for development
* Removes/hides Enterprise and IAP upsell banners where possible
* Provides OCA web UX enhancements
* Serves as mandatory dependency for all InsightPulse modules

This is the foundation of the "18 oca" target image strategy - building
enterprise-grade functionality using only CE + OCA modules.

Usage
-----
All InsightPulse (ipai_*) modules should depend on this module.

License: LGPL-3
    """,
    "author": "InsightPulseAI",
    "website": "https://erp.insightpulseai.net",
    "license": "LGPL-3",
    "depends": [
        # Core technical modules
        "base",
        "web",
        "mail",
        "base_automation",
        "base_import_module",
        "board",
        # Core business primitives
        "contacts",
        "sale_management",
        "account",
        "hr",
        "project",
        "calendar",
        # OCA web UX (loaded if available)
        # "web_responsive",
        # "web_search_panel", 
        # "web_environment_ribbon",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/hide_enterprise_upsells.xml",
        "data/system_parameters.xml",
    ],
    "demo": [],
    "installable": True,
    "application": False,
    "auto_install": False,
    "post_init_hook": "post_init_hook",
    "images": [
        "static/description/banner.png",
    ],
}

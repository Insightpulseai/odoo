This module allows you to use 4 classes in QWEB reports:

- not-first-page: shows element in every page but first
- not-last-page: shows element in every page but last
- first-page: shows element only on first page
- last-page: shows element only on last page

// Supabase Edge Function: semantic-export-osi
// Purpose: Export semantic model + dims + metrics as a vendor-neutral JSON payload,
// and optionally render a simple OSI-like YAML string.
//
// GET /functions/v1/semantic-export-osi?asset_fqdn=...&model_name=...
//
// Auth: Bearer token required. Uses service_role key to read (can be changed to anon if desired).

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

function json(res: unknown, status = 200) {
  return new Response(JSON.stringify(res), { status, headers: { "content-type": "application/json; charset=utf-8" }});
}
function requireEnv(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

function toYaml(obj: any, indent = 0): string {
  const sp = "  ".repeat(indent);
  if (Array.isArray(obj)) {
    return obj.map((v) => `${sp}- ${typeof v === "object" ? "\n" + toYaml(v, indent + 1) : String(v)}`).join("\n");
  }
  if (obj && typeof obj === "object") {
    return Object.entries(obj).map(([k, v]) => {
      if (v === null || v === undefined) return `${sp}${k}: null`;
      if (typeof v === "object") return `${sp}${k}:\n${toYaml(v, indent + 1)}`;
      return `${sp}${k}: ${String(v).includes(":") ? JSON.stringify(v) : String(v)}`;
    }).join("\n");
  }
  return `${sp}${String(obj)}`;
}

serve(async (req) => {
  try {
    if (req.method !== "GET") return json({ error: "Method not allowed" }, 405);
    const auth = req.headers.get("authorization") || "";
    if (!auth.toLowerCase().startsWith("bearer ")) return json({ error: "Missing bearer token" }, 401);

    const SUPABASE_URL = requireEnv("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = requireEnv("SUPABASE_SERVICE_ROLE_KEY");
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

    const url = new URL(req.url);
    const asset_fqdn = url.searchParams.get("asset_fqdn");
    const model_name = url.searchParams.get("model_name") || "default";
    const format = url.searchParams.get("format") || "json"; // json|yaml|both

    if (!asset_fqdn) return json({ error: "asset_fqdn required" }, 400);

    const { data: assets, error: aErr } = await supabase.from("catalog.assets").select("asset_id,fqdn,title,description,system,uri,metadata").eq("fqdn", asset_fqdn).limit(1);
    if (aErr) return json({ error: aErr.message, details: aErr }, 500);
    const asset = assets?.[0];
    if (!asset) return json({ error: "asset not found" }, 404);

    const { data: sms, error: smErr } = await supabase.from("catalog.semantic_models").select("*").eq("asset_id", asset.asset_id).eq("name", model_name).limit(1);
    if (smErr) return json({ error: smErr.message, details: smErr }, 500);
    const sm = sms?.[0];
    if (!sm) return json({ error: "semantic model not found" }, 404);

    const { data: dims, error: dErr } = await supabase.from("catalog.semantic_dimensions").select("*").eq("semantic_model_id", sm.semantic_model_id).order("name");
    if (dErr) return json({ error: dErr.message, details: dErr }, 500);

    const { data: mets, error: mErr } = await supabase.from("catalog.semantic_metrics").select("*").eq("semantic_model_id", sm.semantic_model_id).order("name");
    if (mErr) return json({ error: mErr.message, details: mErr }, 500);

    const payload = {
      asset_fqdn,
      asset: asset,
      semantic_model: sm,
      dimensions: dims || [],
      metrics: mets || [],
      osi: {
        version: "0.1",
        model: {
          name: sm.name,
          label: sm.label,
          description: sm.description,
          grain: sm.grain,
          default_time_column: sm.default_time_column,
          status: sm.status,
        },
        dimensions: (dims || []).map((d:any)=>({ name:d.name, label:d.label, column_ref:d.column_ref, is_time:d.is_time, data_type:d.data_type, hierarchy_key:d.hierarchy_key })),
        metrics: (mets || []).map((m:any)=>({ name:m.name, label:m.label, metric_type:m.metric_type, expression:m.expression, format:m.format, unit:m.unit, certified:m.certified })),
      }
    };

    if (format === "json") return json(payload, 200);
    const yaml = toYaml(payload.osi);

    if (format === "yaml") {
      return new Response(yaml, { status: 200, headers: { "content-type": "text/yaml; charset=utf-8" }});
    }
    return json({ ...payload, osi_yaml: yaml }, 200);
  } catch (e) {
    return json({ error: String((e as any)?.message || e) }, 500);
  }
});

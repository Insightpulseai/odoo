# -*- coding: utf-8 -*-
# =============================================================================
# InsightPulse ERP - Accounting Firm Industry Pack
# =============================================================================
# Specialized workspaces for accounting firm client management
# =============================================================================
{
    "name": "InsightPulse Accounting Firm",
    "version": "18.0.1.0.0",
    "category": "Accounting",
    "summary": "Accounting firm workspace bundle with client engagement management",
    "description": """
InsightPulse Accounting Firm Industry Pack
==========================================

Specialized workspaces and workflows for accounting firms managing multiple clients.

Features
--------
* Per-client accounting workspaces (accounting_client type)
* Link workspaces to projects and analytic accounts
* Track next closing dates for month/quarter/year-end
* Client engagement timeline and milestones
* Integration with Odoo Accounting and Projects

Workspace Extensions
--------------------
* accounting_project_id: Link to primary engagement project
* analytic_account_id: Link to client analytic account
* next_closing_date: Track upcoming closing deadlines

Usage
-----
Install this module to enable the "Client Workspaces" menu with accounting-specific
fields and workflows.

License: LGPL-3
    """,
    "author": "InsightPulseAI",
    "website": "https://erp.insightpulseai.net",
    "license": "LGPL-3",
    "depends": [
        "ipai_workspace_core",
        "account",
        "project",
        "sale_management",
        "calendar",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/workspace_accounting_views.xml",
        "views/workspace_accounting_menus.xml",
    ],
    "demo": [],
    "installable": True,
    "application": False,
    "auto_install": False,
}
